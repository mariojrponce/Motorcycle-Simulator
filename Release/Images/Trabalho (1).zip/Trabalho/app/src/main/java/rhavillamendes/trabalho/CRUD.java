package rhavillamendes.trabalho;

import java.util.ArrayList;

public class CRUD {

    private ArrayList<String> nomes =new ArrayList<>();

    public void save(String nome)
    {
       nomes.add(nome);
    }

    public ArrayList<String> getnomes()
    {

        return nomes;
    }

    public Boolean update(int position, String newNome)
    {
       try {
           nomes.remove(position);
           nomes.add(position,newNome);

           return true;
       }catch (Exception e)
       {
           e.printStackTrace();
          return false;
        }
    }

    public Boolean delete(int position)
    {
        try {
            nomes.remove(position);

            return true;
        }catch (Exception e)
        {
            e.printStackTrace();
            return false;

        }
    }
}
